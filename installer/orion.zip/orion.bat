@echo off
setlocal EnableDelayedExpansion
title Orion -- Neural Semantic PC Search

:: -- Self-elevate to admin (one UAC prompt instead of two) -------------------
net session >nul 2>&1
if errorlevel 1 (
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs -WorkingDirectory '%~dp0'"
    exit /b
)


:: ================================================
::  ORION  |  Multithreaded Neural Semantic Search
::  Starting up...
:: ================================================

cd /d "%~dp0"

cls
echo.
echo     ___  ____  ___ ___  _   _
echo    / _ \^|  _ \^|_ _/ _ \^| \ ^| ^|
echo   ^| ^| ^| ^| ^|_) ^| ^| ^| ^| ^|  \^| ^|
echo   ^| ^|_^| ^|  _ ^< ^| ^| ^|_^| ^| ^|\  ^|
echo    \___/^|_^| \_\___\___/^|_^| \_^|
echo.
echo     Multithreaded Neural Semantic PC Search
echo     =========================================
echo.

:: -- Check Python -----------------------------------------------------------
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found. Please run "Install Orion.bat" first.
    pause
    exit /b 1
)

:: -- Launch Everything (background, for fast NTFS indexing) -----------------
set "EVERYTHING_EXE=%~dp0tools\Everything\Everything.exe"
if exist "%EVERYTHING_EXE%" (
    tasklist /FI "IMAGENAME eq Everything.exe" 2>nul | find /I "Everything.exe" >nul
    if errorlevel 1 (
        start "" /min "%EVERYTHING_EXE%" -startup
        timeout /t 2 /nobreak >nul
    )
)

:: -- Start Orion Backend ----------------------------------------------------
echo  [*] Starting Orion backend...
start "" /min python backend\main.py

echo  [*] Opening Orion in your browser...
timeout /t 2 /nobreak >nul

echo.
echo  +-----------------------------------------+
echo  ^|  Orion is running!                      ^|
echo  ^|  Open:  http://127.0.0.1:8472           ^|
echo  ^|  Hotkey: Ctrl+Space (anywhere)          ^|
echo  ^|  To stop: right-click system tray icon  ^|
echo  +-----------------------------------------+
echo.
echo  This window will close automatically.
timeout /t 4 /nobreak >nul
exit
